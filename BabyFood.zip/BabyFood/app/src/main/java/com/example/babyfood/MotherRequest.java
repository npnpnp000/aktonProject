package com.example.babyfood;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import java.util.Date;
import java.util.concurrent.TimeUnit;

public class MotherRequest extends AppCompatActivity {

    Button next;
    Context context=this;
    ClassRequests request;
    ClassMother mother;
    boolean spcial=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mother_request);

        setPointer();


    }

    private void setPointer() {

        next=findViewById(R.id.btn_help_me);
        mother=(ClassMother) ServerUtil.user;

    }

    public void onClick(View view) {


        switch (view.getId()) {
            case R.id.btn_help_me:
                spcial=false;

                Date timeToday=new Date();
                Log.e("time Today", timeToday.toString());

                if(mother.getStartTime().before(new Date(timeToday.getTime()- TimeUnit.DAYS.toMillis(7)))) {


                    request = new ClassRequests(UserSharePref.getRequestId(mother), mother.getUserID(), "", mother.getMotherAdress()
                            , mother.getpProduct().getProductID(), timeToday, mother.getNumOfProduct(), RequstStatus.waiting);
                    mother.setStartTime(timeToday);
                   // ServerUtil.updateUser(context,mother);

                    // startActivity(new Intent(context, LogIn.class));
                    ServerUtil.saveMothrRequest(context, request,mother);
                }else{

                    request = new ClassRequests(UserSharePref.getRequestId(mother), mother.getUserID(), "", mother.getMotherAdress()
                            , mother.getpProduct().getProductID(), timeToday, mother.getNumOfProduct(), RequstStatus.rejected);

                    // startActivity(new Intent(context, LogIn.class));
                    ServerUtil.saveMothrRequest(context, request,mother);
                }

                final AlertDialog.Builder dlgNewUser = new AlertDialog.Builder(context);

                View myDlgView = LayoutInflater.from(context).inflate(R.layout.positive_negetive, null);

                dlgNewUser.setView(myDlgView);
                LinearLayout rejected=myDlgView.findViewById(R.id.rejected);
                LinearLayout approved=myDlgView.findViewById(R.id.approved);

                if(request.getRequstStatus()==RequstStatus.rejected){
                    rejected.setVisibility(View.VISIBLE);
                    approved.setVisibility(View.GONE);

                    dlgNewUser.setPositiveButton("שלח בקשה מיוחדת", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            spcial=true;
                            dialogInterface.dismiss();

                        }
                    });

                }else {

                    rejected.setVisibility(View.GONE);
                    approved.setVisibility(View.VISIBLE);



                }

                dlgNewUser.setNegativeButton("אישור", new DialogInterface.OnClickListener() {


                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        dialogInterface.dismiss();

                    }
                });


                dlgNewUser.show();

                if(spcial){

                    final AlertDialog.Builder dlgNewUser2 = new AlertDialog.Builder(context);

                    View myDlgView2 = LayoutInflater.from(context).inflate(R.layout.spcial_rquest, null);

                    final EditText s_request=myDlgView2.findViewById(R.id.s_request);


                    dlgNewUser2.setView(myDlgView2);


                    dlgNewUser2.setNegativeButton("ביטול", new DialogInterface.OnClickListener() {


                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {

                            dialogInterface.dismiss();

                        }
                    });

                    dlgNewUser2.setPositiveButton("שלח בקשה מיוחדת", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            request.setRequestDetails(s_request.getText().toString());
                           ServerUtil.updteStatusMothrRequest(context,request,RequstStatus.special);

                            dialogInterface.dismiss();

                        }
                    });


                    dlgNewUser2.show();
                }
                Date dayNow=new Date();
                mother.setStartTime(dayNow);

               // ServerUtil.updateMothr(context,mother);



                break;


        }
    }

    public String getProductId(ClassMother m) {
        return m.getpProduct().getProductID();
    }
}
