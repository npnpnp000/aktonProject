package com.example.babyfood;

/**
 * Created by mazal on 16/03/2018.
 */

public enum RequstStatus {

    rejected,waiting,onTheWay,special,arrived

}
