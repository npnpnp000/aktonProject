package com.example.babyfood;

/**
 * Created by איילת on 25/02/2018.
 */

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by mazal on 23/01/2018.
 */

public class MyRecyclerViewAdapter extends RecyclerView.Adapter<MyRecyclerViewAdapter.DataObjectHolder> {

    //set title for our tag
    private static String TAG = "MyRecyclerViewAdapter";
    //our data set list
    private List<DataObject> lstDataSet;
    //our click listener that will be sent by a method
    private static MyClickListener myClickListener;



    //create our listener interface
    public interface MyClickListener {
        public void onItemClick(int position, View v);
    }

    //cto'r to our class
    public MyRecyclerViewAdapter(List<Tables> myDataSet) {
        lstDataSet=  getHelpRequest(myDataSet);
    }



    public static class DataObjectHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView food_request;

        public DataObjectHolder(View itemView) {
            super(itemView);
            food_request = itemView.findViewById(R.id.food_request);


            Log.e(TAG, "DataObjectHolder: adding listener");
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            myClickListener.onItemClick(getAdapterPosition(), view);
        }
    }

    //using the interface we set on click listener but for single item.
    public void setOnItemClickListener(MyClickListener myClickListener)
    {
        this.myClickListener=myClickListener;
    }

    //create a view holder, which will be created upon using it.
    @Override
    public DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //inflate our card view row layout
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_requests,parent,false);
        //set the inflated view to our holder
        DataObjectHolder dataObjectHolder = new DataObjectHolder(view);
        //return the data object holder
        return dataObjectHolder;
    }

    //once the view is presented
    @Override
    public void onBindViewHolder(DataObjectHolder holder, int position) {
        //set the label (our header which show index : XX)

        //set the next text view
        holder.food_request.setText(lstDataSet.get(position).getmText1());
    }

    //for adding a new item to the list (can be achived with FAB or menu or button
    public void addItem(DataObject dataObj, int index)
    {
        lstDataSet.add(index,dataObj);

        notifyItemInserted(index);
    }

    //for deleting a pecific item by index
    public void deleteItem(int index)
    {
        lstDataSet.remove(index);
        notifyItemRemoved(index);
    }

    //get total of items....
    @Override
    public int getItemCount() {
        return lstDataSet.size();
    }

    private List<DataObject> getHelpRequest(List<Tables> myDataSet) {

        List<DataObject> returnList=new ArrayList<>();
        for (int i=0;i<myDataSet.size();i+=1){
            myDataSet.get(i).getStatusOfRequest().name().equals(StatusOfRequest.waiting.name());
            }

        return returnList;
    }


}
