package com.example.babyfood;

import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.Date;
import java.util.concurrent.TimeUnit;

public class Gate extends AppCompatActivity {

    Context context=this;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gate);

       setPoiner();




    }

    private void setPoiner() {
     /*   Date d=new Date();
        Date wbt=new Date(d.getTime()- TimeUnit.DAYS.toMillis(8));
        ClassProduct p=new ClassProduct("materna_1","materna 1");
        ClassMother m=new ClassMother("1234",1,"sham",wbt,p,
                "mom","mami","1234","1111",""
                ,"mother",1);
        ServerUtil.saveUser(context,m);

       UserSharePref.setLogin("mother",UserStatus.mother,context);*/


        if(UserSharePref.getUser(context).equals("null")){

            startActivity(new Intent(context, LogIn.class));
        }else{

           ServerUtil.getUserByID(context,UserSharePref.getUser(context));

           while (ServerUtil.user==null){}

           switch (ServerUtil.user.getUserStatus().ordinal()){
               case 1:{
                   startActivity(new Intent(context, LogIn.class));//need to be deliverMans
                   break;

               }
               case 3:{
                   startActivity(new Intent(context, MotherID.class));
                   break;

               }
              default:{
                  startActivity(new Intent(context, LogIn.class));
                  break;

              }
           }

        }


    }


}
