package com.example.babyfood;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.cloudant.client.api.ClientBuilder;
import com.cloudant.client.api.CloudantClient;
import com.cloudant.client.api.Database;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Date;

/**
 * Created by mazal on 05/03/2018.
 */

public class ServerUtil {

    public static ClassUsers user;

   /* public static boolean isFinish() {
        return finish;
    }*/

   private static Boolean spcial=false;




    @SuppressLint("StaticFieldLeak")
    public  static void getUserByID(Context context, final String _id){

        final Context _context=context;
      //  finish=false;


        new AsyncTask<Void, Void, Void>() {

            @Override
            protected Void doInBackground(Void... voids) {


                CloudantClient client = ClientBuilder
                        .account("95613fd3-944b-4748-9aee-03831760e1c4-bluemix")
                        .username("fromeenderembreeksmaided")
                        .password("20a8e0acb1965a25f16e0596e310c1c2e4648e8b")
                        .build();

                Database db = client.database("materna_users", false);
                 UserStatus userStatus = null;
               // db.save(_user);
               // user= db.find(ClassUsers.class,id);
                InputStream inputStream;
                inputStream=db.find(_id);

               String status= getStatusfroId(inputStream);

                Log.e("JSON statos:",status.toString());
                    userStatus=UserStatus.valueOf( status);


                switch (userStatus.ordinal()){

                    case 0:
                    {

                      // user= db.find(ClassManager.class,_id);
                        break;
                    }
                    case 1:
                    {
                        //db.save((ClassDeliveryMans)_user,ClassDeliveryMans.class);
                      //  user= db.find(ClassDeliveryMans.class,_id);
                        break;
                    }
                    case 2:
                    {
                        //db.save((ClassMachsenai)_user,ClassMachsenai.class);
                        //  user= db.find(ClassMachsenai.class,id);
                        break;
                    }
                    case 3:
                    {
                        user= db.find(ClassMother.class,_id);
                        Log.e("user:" ,"now is: "+((ClassMother)user).getUserID());
                        break;
                    }
                    case 4:
                    {
                        //db.save((payMan)_user,Manager.class);
                        //user= db.find(payMan.class,_id);
                        break;
                    }
                    case 5:
                    {
                        //db.save((Manager)_user,Manager.class);
                        // //user= db.find(Manager.class,_id);
                        break;
                    }
                    default:
                    {

                    }
                }

             /*   try {
                    helpRequests = db.getAllDocsRequestBuilder().includeDocs(true).build().getResponse().getDocsAs(HelpRequest.class);
                } catch (IOException e) {
                    e.printStackTrace();
                }*/

                return null;
            }

            @Override
            protected  void onPostExecute(Void aVoid) {

               // finish=true;

                Toast.makeText(_context, "Data was saved...", Toast.LENGTH_SHORT).show();

            }
        }.execute();
    }

    private static String getStatusfroId(InputStream id) {
        String s[];
        BufferedReader r = new BufferedReader(new InputStreamReader(id));
        StringBuilder total = new StringBuilder();
        String line;
        try {
            while ((line = r.readLine()) != null) {
                total.append(line).append('\n');
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
       s= total.toString().split("\"");
        for (int i=0; i<s.length;i+=1) {
            Log.e("spit String: ",s[i]+"/n");
            if(s[i].equals("userStatus")){
                return s[i+2];
            }
        }
        return null;
    }


    @SuppressLint("StaticFieldLeak")
    public static void saveUser(Context context, ClassUsers user){

    final Context _context=context;
    final ClassUsers _user=user;

        new AsyncTask<Void, Void, Void>() {

            @Override
            protected Void doInBackground(Void... voids) {


                CloudantClient client = ClientBuilder
                        .account("95613fd3-944b-4748-9aee-03831760e1c4-bluemix")
                        .username("fromeenderembreeksmaided")
                        .password("20a8e0acb1965a25f16e0596e310c1c2e4648e8b")
                        .build();

                Database db = client.database("materna_users", false);

                db.save(_user);
              // String s= String.valueOf(db.find("test"));


              /*  switch (_user.getUserStatus().ordinal()){

                    case 0:
                    {
                        //db.save((ClassManager)_user,ClassManager.class);
                        break;
                    }
                    case 1:
                    {
                        //db.save((ClassDeliveryMans)_user,ClassDeliveryMans.class);
                        break;
                    }
                    case 2:
                    {
                        //db.save((ClassMachsenai)_user,ClassMachsenai.class);
                        break;
                    }
                    case 3:
                    {
                        db.save((ClassMother)_user);
                        break;
                    }
                    case 4:
                    {
                        //db.save((Manager)_user,Manager.class);
                        break;
                    }
                    case 5:
                    {
                        //db.save((Manager)_user,Manager.class);
                        break;
                    }
                    default:
                    {

                    }
                }*/

             /*   try {
                    helpRequests = db.getAllDocsRequestBuilder().includeDocs(true).build().getResponse().getDocsAs(HelpRequest.class);
                } catch (IOException e) {
                    e.printStackTrace();
                }*/

                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {

                //finish=true;


                Toast.makeText(_context, "Data was saved...", Toast.LENGTH_SHORT).show();

            }
        }.execute();




    }
    public static void updateMothr(Context context, final ClassMother user){

        final Context _context=context;


        new AsyncTask<Void, Void, Void>() {

            @Override
            protected Void doInBackground(Void... voids) {


                CloudantClient client = ClientBuilder
                        .account("95613fd3-944b-4748-9aee-03831760e1c4-bluemix")
                        .username("fromeenderembreeksmaided")
                        .password("20a8e0acb1965a25f16e0596e310c1c2e4648e8b")
                        .build();

                Database db = client.database("materna_users", false);


                db.update(user);


                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {

                //finish=true;


                Toast.makeText(_context, "Data was saved...", Toast.LENGTH_SHORT).show();

            }
        }.execute();




    }


    @SuppressLint("StaticFieldLeak")
    public static void updteStatusMothrRequest(final Context context, final ClassRequests request,final RequstStatus newRequstStatus){

        final Context _context=context;


        new AsyncTask<Void, Void, Void>() {

            @Override
            protected Void doInBackground(Void... voids) {


                CloudantClient client = ClientBuilder
                        .account("95613fd3-944b-4748-9aee-03831760e1c4-bluemix")
                        .username("whengengeoulthellyinkild")
                        .password("d1f0339acf2505380a25a00fa57c796579c88e3e")
                        .build();

                Database db = client.database("mother_requests", false);

                request.setRequstStatus(newRequstStatus);
                db.update(request);


                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {




                Toast.makeText(_context, "Data was saved...", Toast.LENGTH_LONG).show();

            }
        }.execute();




    }

    @SuppressLint("StaticFieldLeak")
    public static void saveMothrRequest(final Context context, final ClassRequests request, final  ClassMother mother){

        final Context _context=context;


        new AsyncTask<Void, Void, Void>() {

            @Override
            protected Void doInBackground(Void... voids) {


                CloudantClient client = ClientBuilder
                        .account("95613fd3-944b-4748-9aee-03831760e1c4-bluemix")
                        .username("whengengeoulthellyinkild")
                        .password("d1f0339acf2505380a25a00fa57c796579c88e3e")
                        .build();

                Database db = client.database("mother_requests", false);

                db.save(request);


                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {



                Toast.makeText(_context, "Data was saved...", Toast.LENGTH_LONG).show();

            }
        }.execute();




    }

}
