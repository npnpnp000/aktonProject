package com.example.babyfood;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MotherID extends AppCompatActivity {

    Context context=this;
    ClassMother mother;
    Button btn_IDcontinue;
    TextView txt_wrongNum;
    EditText log_in_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mother_id);

        setPointer();

    }

    private void setPointer() {

        btn_IDcontinue=findViewById(R.id.btn_IDcontinue);
        txt_wrongNum=findViewById(R.id.txt_wrongNum);
        log_in_id=findViewById(R.id.log_in_id);

      if(ServerUtil.user instanceof ClassMother)  {

          mother = (ClassMother)ServerUtil.user;
          Toast.makeText(context, mother.getFirstName()+" :successes", Toast.LENGTH_SHORT).show();
      }

    }

    public void onClick(View view) {


        switch (view.getId()) {
            case R.id.btn_IDcontinue:

                logIn();

                break;

        }
    }

    private void logIn() {

        txt_wrongNum.setVisibility(View.GONE);
        Log.e("Mother id ",""+mother.getMotherID());

        if(mother.getMotherID().equals(log_in_id.getText().toString())){

            startActivity(new Intent(context, MotherRequest.class));
        }else {
            txt_wrongNum.setVisibility(View.VISIBLE);
        }


    }


}
