package com.example.babyfood;

/**
 * Created by איילת on 01/03/2018.
 */

public class ClassDeliveryMans {

    enum status {free, onTheWay, notWorking}
    String location;
    status status;

    public ClassDeliveryMans(String location, ClassDeliveryMans.status status) {
        this.location = location;
        this.status = status;
    }

    public ClassDeliveryMans() {
    }

    public String getLocation() {
        return location;
    }

    public ClassDeliveryMans.status getStatus() {
        return status;
    }

    public void setStatus(ClassDeliveryMans.status status) {
        this.status = status;
    }
}
