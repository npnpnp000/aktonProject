package com.example.babyfood;

import android.content.Context;
import android.provider.Settings;

import java.util.Date;

/**
 * Created by איילת on 01/03/2018.
 */

public class ClassMother implements ClassUsers {

    private String motherID;
    private int numChildren;
    private String motherAdress;
    private Date startTime;
    private ClassProduct product;
    private String firstName;
    private String lastName;
    private String password;
    private String telephoneNum;
    private String androidID;
    private String _id;
    private UserStatus userStatus;
    private int numOfProduct;

    public ClassMother(String motherID, int numChildren, String motherAdress, Date startTime,
                       ClassProduct product, String firstName, String lastName, String password,
                       String telephoneNum, String androidID, String userID, int numOfProduct) {
        this.motherID = motherID;
        this.numChildren = numChildren;
        this.motherAdress = motherAdress;
        this.startTime = startTime;
        this.product=product;
        this.firstName = firstName;
        this.lastName = lastName;
        this.password = password;
        this.telephoneNum = telephoneNum;
        this.androidID = androidID;
        this._id = userID;
        this.userStatus = userStatus.mother;
        this.numOfProduct=numOfProduct;
    }

    public ClassMother() {
    }

    public int getNumOfProduct() {
        return numOfProduct;
    }

    public void setNumOfProduct(int numOfProduct) {
        this.numOfProduct = numOfProduct;
    }

    public UserStatus getUserStatus() {
        return userStatus;
    }

    public String getMotherID() {
        return motherID;
    }

    public int getNumChildren() {
        return numChildren;
    }

    public void setNumChildren(int numChildren) {
        this.numChildren = numChildren;
    }

    public String getMotherAdress() {
        return motherAdress;
    }

    public void setMotherAdress(String motherAdress) {
        this.motherAdress = motherAdress;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public ClassProduct getpProduct() {
        return product;
    }

    public void setProduct(ClassProduct product) {
        this.product = product;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getTelephoneNum() {
        return telephoneNum;
    }

    public void setTelephoneNum(String telephoneNum) {
        this.telephoneNum = telephoneNum;
    }

    public String getAndroidID() {
        return androidID;
    }

    public void setAndroidID(Context context) {
        this.androidID = Settings.Secure.getString(context.getContentResolver(),
                Settings.Secure.ANDROID_ID);
    }

    public String getUserID() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    @Override
    public String toString() {
        return "ClassMother{" +
                "motherID=" + motherID +
                ", numChildren=" + numChildren +
                ", motherAdress='" + motherAdress + '\'' +
                ", startTime='" + startTime + '\'' +
                ", product='" + product + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", password='" + password + '\'' +
                ", telephoneNum='" + telephoneNum + '\'' +
                ", androidID='" + androidID + '\'' +
                ", _id='" + _id + '\'' +
                ", userStatus=" + userStatus +
                '}';
    }
}