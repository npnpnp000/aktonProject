package com.example.babyfood;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LogIn extends AppCompatActivity {

    Context context = this;
    Button btn_continue;
    EditText log_in_name, log_in_password;
    TextView txt_worongPass, txt_worongUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.log_in);

        setPointer();
    }

    private void setPointer() {

        btn_continue = findViewById(R.id.btn_continue);
        log_in_name = findViewById(R.id.log_in_name);
        log_in_password = findViewById(R.id.log_in_password);
        txt_worongPass = findViewById(R.id.txt_worongPass);
        txt_worongUser = findViewById(R.id.txt_worongPass);

    }

    public void onClick(View view) {


        switch (view.getId()) {
            case R.id.btn_continue:

                logIn();

                break;

        }
    }

    private  void logIn() {



        Runnable r=new Runnable() {

            public  void  run(){


                txt_worongUser.setVisibility(View.GONE);
        txt_worongPass.setVisibility(View.GONE);

        ServerUtil.getUserByID(context, log_in_name.getText().toString());

                while (ServerUtil.user==null) {
                }


        Toast.makeText(context,"thred over",Toast.LENGTH_LONG);
        if (ServerUtil.user == null) {


            txt_worongUser.setVisibility(View.VISIBLE);

        } else if (!ServerUtil.user.getPassword().equals(log_in_password.getText().toString())) {


            txt_worongPass.setVisibility(View.VISIBLE);
        } else {

            switch (ServerUtil.user.getUserStatus().ordinal()) {
                case 3: {
                    UserSharePref.setLogin(((ClassMother)ServerUtil.user).getUserID(),(ServerUtil.user).getUserStatus(),context);

                    startActivity(new Intent(context, MotherID.class));
                }

            }
        }


    }
    };

        runOnUiThread(r);

    }


}
//https://www.2help.org.il/