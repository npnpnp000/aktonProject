package com.example.babyfood;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import java.util.UUID;

/**
 * Created by mazal on 06/03/2018.
 */



public class UserSharePref {

   private static int cuntRequestId=0;

    public static void deleteAllSePeferences(Context context) {


        SharedPreferences prefs1 = context.getSharedPreferences("userLoginPrefs", Context.MODE_PRIVATE);

        SharedPreferences.Editor editor1 = prefs1.edit();

        editor1.clear();

        editor1.commit();

    }


    public static void setLogin(String userID,UserStatus status, Context context) {

        SharedPreferences prefs = context.getSharedPreferences("userLoginPrefs", Context.MODE_PRIVATE);

        SharedPreferences.Editor editor = prefs.edit();
        editor.clear();


        editor.putString("userID", userID);
        editor.putString("userStatus", status.toString());


        editor.commit();
        Log.e("set Login:", "end");
    }

    public static String getUser( Context context) {

        SharedPreferences prefs = context.getSharedPreferences("userLoginPrefs", Context.MODE_PRIVATE);



        if (prefs == null) {
            Log.e("check Login", "retern false");
            return "null";
        }
        String re = prefs.getString("userID", "def");
        if (re.equals("def")) {

            return "null";

        }else{return re;}

    }

    public static UserStatus getUserStatus( Context context) {

        SharedPreferences prefs = context.getSharedPreferences("userLoginPrefs", Context.MODE_PRIVATE);

        UserStatus re=UserStatus.valueOf(prefs.getString("userStatus","payMan"));

        return re;

    }
    public static String getRequestId(ClassMother mother){

        Log.e("getRequestId",""+(cuntRequestId+=1)+"/"+mother.getUserID());
        return ""+cuntRequestId+"/"+mother.getUserID()+"/"+ UUID.randomUUID().toString();
    }
}
