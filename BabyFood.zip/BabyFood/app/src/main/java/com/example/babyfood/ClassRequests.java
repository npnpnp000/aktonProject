package com.example.babyfood;

import java.util.Date;

/**
 * Created by איילת on 01/03/2018.
 */

public class ClassRequests {

   private String _id;
    private String motherRequstId;
    private String deliveryDetails;
    private String deliveryAdress;
    private String productId;
    private Date timeRequest;
    private int cuntProduct;
    private RequstStatus requstStatus;
    private String requestDetails ="Aotu request";

    public ClassRequests(String RequestId, String motherRequstId, String deliveryDetails, String deliveryAdress,
                         String productId, Date timeRequest ,int cuntProduct,RequstStatus requstStatus) {
        this._id = RequestId;
        this.motherRequstId = motherRequstId;
        this.deliveryDetails = deliveryDetails;
        this.deliveryAdress = deliveryAdress;
        this.productId = productId;
        this.timeRequest = timeRequest;
        this.cuntProduct=cuntProduct;
        this.requstStatus=requstStatus;
    }

    public ClassRequests() {
    }

    public String getRequestDetails() {
        return requestDetails;
    }

    public void setRequestDetails(String requestDetails) {
        this.requestDetails = requestDetails;
    }

    public RequstStatus getRequstStatus() {
        return requstStatus;
    }

    public void setRequstStatus(RequstStatus requstStatus) {
        this.requstStatus = requstStatus;
    }

    public String get_id() {
        return _id;
    }

    public String getMotherRequstId() {
        return motherRequstId;
    }

    public String getDeliveryDetails() {
        return deliveryDetails;
    }

    public String getDeliveryAdress() {
        return deliveryAdress;
    }

    public String getProductId() {
        return productId;
    }

    public Date getTimeRequest() {
        return timeRequest;
    }

    public int getCuntProduct() {
        return cuntProduct;
    }
}