package com.example.babyfood;

/**
 * Created by איילת on 25/02/2018.
 */

class DataObject {
    private String mText1;


    public DataObject(String mText1 ) {
        this.mText1 = mText1;

    }

    public String getmText1() {
        return mText1;
    }

    public void setmText1(String mText1) {
        this.mText1 = mText1;
    }


}
