package com.example.babyfood;

/**
 * Created by $ Ayelet on 01/03/2018.
 */

public class ClassMachsenai  {

    String machsanLocation;

}
