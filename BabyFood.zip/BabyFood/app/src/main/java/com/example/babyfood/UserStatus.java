package com.example.babyfood;

/**
 * Created by mazal on 05/03/2018.
 */

public enum UserStatus {

    manager, DeliveryMan, machsenai, mother, payMan, pkida

}
