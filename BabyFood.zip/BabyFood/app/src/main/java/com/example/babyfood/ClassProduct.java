package com.example.babyfood;

/**
 * Created by mazal on 16/03/2018.
 */

public class ClassProduct {

  private String productID;
    private String details;

    public ClassProduct(String productID, String details) {
        this.productID = productID;
        this.details = details;
    }

    public ClassProduct() {
    }

    public String getProductID() {
        return productID;
    }

    public String getDetails() {
        return details;
    }
}
