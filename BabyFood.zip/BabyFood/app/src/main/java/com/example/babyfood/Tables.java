package com.example.babyfood;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.util.Log;

import com.cloudant.client.api.ClientBuilder;
import com.cloudant.client.api.CloudantClient;
import com.cloudant.client.api.Database;

import java.util.Date;
import java.util.UUID;

/**
 * Created by איילת on 25/02/2018.
 */


    /**
     * Created by mazal on 01/01/2018.
     */

    enum StatusOfRequest{waiting, on_the_way, over}

    public  class Tables {


        private String userId;

        private String _id;
        private StatusOfRequest statusOfRequest;
        private String helpRequestDateOfCreate;


        public Tables() {
        }

        public Tables( String userId, StatusOfRequest statusOfRequest) {

            this.userId = userId;
            this.statusOfRequest = statusOfRequest;
            this._id= UUID.randomUUID().toString();
            this.helpRequestDateOfCreate=new Date().toString();

        }



        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public String get_id() {
            return _id;
        }

        public void set_id(String _id) {
            this._id = _id;
        }

        public StatusOfRequest getStatusOfRequest() {
            return statusOfRequest;
        }

        public void setStatusOfRequest(StatusOfRequest statusOfRequest) {
            this.statusOfRequest = statusOfRequest;
        }

        @Override
        public String toString() {
            return "HelpRequest{" +

                    ", userId='" + userId + '\'' +
                    ", _id='" + _id + '\'' +
                    ", statusOfRequest=" + statusOfRequest +
                    ", helpRequestDateOfCreate='" + helpRequestDateOfCreate + '\'' +
                    '}';
        }

        @SuppressLint("StaticFieldLeak")
        public void SendRequest(Tables hl){

            final String API_KEY="";
            final String API_SECRET="";
            final String API_GATEWAY="";
            final String API_DB="";
            final Tables fHL=hl;




                new AsyncTask<Void, Void, Void>() {

                    @Override
                    protected Void doInBackground(Void... voids) {
                        //lets connect to our DB.
                        CloudantClient client = ClientBuilder
                                .account(API_GATEWAY)
                                .username(API_KEY)
                                .password(API_SECRET)
                                .build();

                        Database db = client.database(API_DB, false);



                        db.save(fHL);

                        return null;
                    }

                    @Override
                    protected void onPostExecute(Void aVoid) {
                        Log.e("HelpRequest","save help request: "+this.toString());
                        //  Toast.makeText(context, "Data was saved...", Toast.LENGTH_SHORT).show();
                        // txtMsg.setText("The request sent ");
                    }
                }.execute();



        }
    }
